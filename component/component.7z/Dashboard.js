import React from 'react';
import {
  View,
  FlatList,
  StyleSheet,
  Text,
  Image,
  SafeAreaView,
  Button,
} from 'react-native';

function List({title, desc, img}) {
  return (
    <View style={styles.item}>
      <Image style={styles.thumb} source={{uri: img}} />
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.news}>"{desc}"</Text>
    </View>
  );
}

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      news: {},
    };
  }

  componentDidMount() {
    fetch(
      'https://newsapi.org/v2/top-headlines?country=us&apiKey=440b65e170ae42ae9807d7db0e93227a',
    )
      .then(response => response.json())
      .then(responseJson => {
        // console.log(responseJson);
        let news = responseJson.articles.map(obj => ({
          title: obj.title,
          desc: obj.description,
          img: obj.urlToImage,
        }));
        this.setState({news: news});
        console.log(this.state.news);
      })
      .catch(error => {
        console.error(error, 'a');
      });
  }

  logout = () => {
    console.log(this.props);
    this.props.navigation.navigate('Login');
  };

  render() {
    return (
      <SafeAreaView style={styles.container}>
        <Button
          title="LOGOUT"
          style={styles.btLogout}
          onPress={() => this.logout()}
        />
        <View>
          <FlatList
            data={this.state.news}
            renderItem={obj => (
              <List
                title={obj.item.title}
                desc={obj.item.desc}
                img={obj.item.img}
              />
            )}
            keyExtractor={(itm, i) => i.toString()}
          />
        </View>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 10,
  },
  item: {
    flex: 1,
    backgroundColor: '#ded',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
    textAlign: 'center',
  },
  news: {
    fontSize: 15,
  },

  thumb: {
    width: 100,
    height: 50,
  },

  btLogout: {
    flex: 1,
    backgroundColor: 'red',
  },
});
