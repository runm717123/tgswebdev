import React, {Component} from 'react';
import {Container, Content} from 'native-base';
import {MyList} from './misc/CustomItem';
import {connect} from 'react-redux';

class DocList extends Component {
  static navigationOptions = {
    title: 'Dokumen',
  };

  render() {
    const list = [
      {
        title: 'Kembali ke Menu',
        click: () => this.props.navigation.navigate('Dashboard'),
      },
      ...this.props.cargo.map(i => ({
        title: i.title,
        click: () =>
          this.props.navigation.navigate('Form', {
            title: i.title,
            content: i.content,
          }),
      })),
    ];
    return (
      <Container>
        <Content padder>
          <MyList list={list} />
        </Content>
      </Container>
    );
  }
}

const mapStateToProps = state => {
  return {
    cargo: state.noteRdc.cargo,
  };
};

export default connect(mapStateToProps)(DocList);
