import React, {Component} from 'react';
import {connect} from 'react-redux';
import {StyleSheet} from 'react-native';
import {acSave} from '../../../src/redux/actionCreators';
import {
  Container,
  Header,
  Content,
  Item,
  Input,
  Icon,
  Textarea,
  Button,
  Text,
} from 'native-base';
class NoteForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      title: this.props.navigation.getParam('title', 'File baru'),
      content: this.props.navigation.getParam('content', ''),
    };
    this._handleSave = this._handleSave.bind(this);
  }

  _handleSave() {
    this.props.save(this.state);
    console.log(this.props);
  }

  static navigationOptions = ({navigation}) => ({
    title: navigation.getParam('title', 'File baru'),
  });

  render() {
    return (
      <Container>
        <Content padder>
          <Item primary>
            <Input
              placeholder="judul"
              onChangeText={e => this.setState({title: e})}
              value={this.state.title}
            />
            <Icon name="checkmark-circle" />
          </Item>
          <Textarea
            rowSpan={5}
            bordered
            placeholder="isi"
            onChangeText={e => this.setState({content: e})}
            value={this.state.content}
          />

          <Button block onPress={this._handleSave} danger>
            <Text>Simpan</Text>
          </Button>
        </Content>
      </Container>
    );
  }
}

const mapStateToProps = state => {
  return {
    cargo: state.noteRdc,
  };
};

export default connect(
  mapStateToProps,
  acSave,
)(NoteForm);
