// import React from 'react';
import {createAppContainer} from 'react-navigation';
import {createStackNavigator} from 'react-navigation-stack';
// import {connect} from 'react-redux';
// import {acLogin} from '../src/redux/actions';
import ShopForm from './form/ShopP';
import ShopDashboard from './ShopDashB';
import DocList from './DocList';

const Start = createStackNavigator(
  {
    Dashboard: ShopDashboard,
    Form: ShopForm,
    Document: DocList,
  },
  {
    // headerMode: 'none',
    headerLayoutPreset: 'center',
    // initialRouteName: 'ExperimentPage',
    initialRouteName: 'Dashboard',
    defaultNavigationOptions: {
      headerTintColor: 'green',
      headerStyle: {
        backgroundColor: '#fff',
      },
    },
  },
);

export default createAppContainer(Start);
