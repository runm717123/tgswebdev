import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import imgPicker from 'react-native-image-picker';
import {connect} from 'react-redux';
// import {doRegister, acRegister} from '../redux_file/actions/auth';
import {acRegister} from '../redux_file/actions/auth';

// More info on all the options is below in the API Reference... just some common use cases shown here
const options = {
  title: 'Pilih gambar ... ',
  storageOptions: {
    skipBackup: false,
    path: 'images',
  },
};

class Reg_form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      pass: '',
      photo: {},
    };
    console.log(this.props);
    // this.props.navigation.navigate('Dashboard');
  }

  _takePhoto = () => {
    imgPicker.showImagePicker(options, response => {
      console.log('Response = ', response);

      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        const source = {uri: response.uri};

        // You can also display the image using data:
        // const source = { uri: 'data:image/jpeg;base64,' + response.data };

        this.setState({
          file: response.path,
          uri: 'data:image/jpeg;base64,' + response.data,
        });
      }
    });
  };

  _register = () => {
    console.log(this.state);
    const additional = {
      segment: '',
      method: 'POST',
      body: JSON.stringify({
        'add-user': '',
        name: this.state.name,
        pass: this.state.pass,
        photo: this.state.photo.name,
      }),
    };
    this.props.register(additional);
  };

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.judul}>PENDAFTARAN</Text>
        <View style={styles.form}>
          <TextInput
            placeholder="Tulis nama user.."
            style={styles.edit}
            value={this.state.name}
            onChangeText={t => this.setState({name: t})}
          />
          <TextInput
            placeholder="Kata sandi ..."
            style={styles.edit}
            secureTextEntry={true}
            value={this.state.pass}
            onChangeText={t => this.setState({pass: t})}
          />
          <View style={styles.vEmailJk}>
            <Image
              source={{uri: this.state.uri}}
              style={{width: 100, height: 100}}
            />
            <TouchableOpacity onPress={this._takePhoto}>
              <Image
                style={{width: 50, height: 50}}
                source={require('./img/photo-camera.png')}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.row}>
            <TouchableOpacity
              style={styles.btLogin}
              onPress={() => this.props.navigation.navigate('Login')}>
              <Text style={{fontSize: 12}}>Login !</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.btLogin} onPress={this._register}>
              <Text style={{fontSize: 12}}>Register please !</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

// const mapStateToProps = state => {
//   const {auth} = state;
//   return {
//     name: auth.name,
//     pass: auth.password,
//     photo: auth.photo,
//   };
// };

function mapStateToProps({auth}) {
  return {
    name: auth.name,
    pass: auth.password,
    photo: auth.photo,
  };
}

// const mapDispatchToProps = dispatch => {
//   return {
//     login: payload => {
//       dispatch(doRegister(payload));
//     },
//   };
// };

export default connect(
  mapStateToProps,
  acRegister,
)(Reg_form);

// const a = require('https://fonts.googleapis.com/css?family=Mansalva&display=swap');
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ff0059',
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 200,
    // flexBasis: 100,
  },

  judul: {
    fontSize: 30,
    fontStyle: 'italic',
    textDecorationLine: 'underline',
  },

  form: {
    marginTop: 50,
    borderWidth: 3,
    padding: 40,
  },

  edit: {
    width: 300,
    borderWidth: 1,
    borderColor: '#555',
    borderBottomColor: 'black',
    borderBottomWidth: 2,
    margin: 4,
    borderRadius: 8,
    backgroundColor: '#eee',
    paddingLeft: 15,
    marginVertical: 4,
  },

  row: {
    flexDirection: 'row',
  },
  btLogin: {
    borderRadius: 15,
    borderWidth: 2,
    borderColor: 'black',
    height: 45,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
    backgroundColor: '#fff',
    flex: 1,
  },
  edEmail: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#555',
    borderBottomColor: 'black',
    borderBottomWidth: 2,
    margin: 4,
    borderRadius: 5,
  },
  vEmailJk: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
