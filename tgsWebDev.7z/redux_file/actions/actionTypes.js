export const authActions = {
  doLogin: 'AUTH_DO_LOGIN',
  doLogout: 'AUTH_DO_LOGOUT',
  doRegister: 'AUTH_DO_REGISTER',
};
