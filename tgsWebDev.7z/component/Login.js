import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import {connect} from 'react-redux';
import {acLogin} from '../redux_file/actions/auth';

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      pass: '',
      loggedIn: false,
    };
    // console.log(this, 'LOGIN.js');
  }

  _login = () => {
    console.log(this.state, 'login pressedd');
    const additional = {
      segment: '',
      method: 'POST',
      body: JSON.stringify({
        getOneUser: '',
        name: this.state.name,
        pass: this.state.pass,
      }),
    };
    this.props.login(additional);
  };

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.judul}>LOG-IN</Text>
        <View style={styles.form}>
          <TextInput
            placeholder="Tulis nama user.."
            style={styles.edit}
            onChangeText={t => this.setState({name: t})}
          />
          <TextInput
            placeholder="Kata sandi ..."
            style={styles.edit}
            onChangeText={t => this.setState({pass: t})}
          />
          <View style={styles.grButton}>
            <TouchableOpacity style={styles.btLogin} onPress={this._login}>
              <Text style={{fontSize: 12}}>Login !</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.btLogin}
              // onPress={() => console.log(this)}
              onPress={() => this.props.navigation.navigate('Register')}>
              <Text style={{fontSize: 12}}>Register !</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

// const mapStateToProps = state => {
//   const {auth} = state;
//   return {
//     name: auth.name,
//     pass: auth.password,
//     photo: auth.photo,
//   };
// };

function mapStateToProps({auth}) {
  return {
    name: auth.name,
    pass: auth.password,
    photo: auth.photo,
  };
}

// const mapDispatchToProps = dispatch => {
//   return {
//     login: payload => {
//       dispatch(doLogin(payload));
//     },
//   };
// };

export default connect(
  mapStateToProps,
  acLogin,
)(Login);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#45f7dd',
    alignItems: 'center',
    justifyContent: 'center',
    // flexBasis: 100,
  },

  judul: {
    fontSize: 30,
    fontStyle: 'italic',
    textDecorationLine: 'underline',
  },

  form: {
    marginTop: 50,
    padding: 10,
    alignSelf: 'stretch',
  },

  edit: {
    // flex: 1,
    borderBottomColor: 'black',
    borderBottomWidth: 2,
    margin: 4,
    color: 'red',
    paddingLeft: 10,
  },

  grButton: {
    flex: 1,
    flexDirection: 'row',
    alignContent: 'space-between',
    // flexBasis: 100,
  },
  btLogin: {
    flex: 1,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: 'black',
    height: 35,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
    backgroundColor: '#fff',
    marginHorizontal: 20,
  },
});
