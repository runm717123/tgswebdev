// import React from 'react';
import {createAppContainer} from 'react-navigation';
import {createStackNavigator} from 'react-navigation-stack';
import Login_form from './Login';
import Reg_nav from './Register';
import Db_nav from './Dashboard';

const page = createStackNavigator(
  {
    Register: Reg_nav,
    Login: Login_form,
    Dashboard: Db_nav,
  },
  {
    headerMode: 'none',
    initialRouteName: 'Register',
  },
);
export default createAppContainer(page);
